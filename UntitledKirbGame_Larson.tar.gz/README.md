# **Cameron Larson's CPSC 4160 game/eventually final project**
-------

## To compile:
extract files and run "make" command


## To run:
run "./my_game" after compiling


## To play:
Use WASD keys to move up, left, down, and right. 
Press the space bar while not moving to flap wings. 
Use the escape key to close the game


## Classes to evaluate:
player/entity
sprite