#include "gameEngine.h"

int main(int argc, char* argv[])
{ 
	//Construct game engine
	gameEngine g;

	//Go to game loop
	g.gameLoop();

	return 0; 
}
